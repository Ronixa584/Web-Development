import React from 'react'

const Footer = () => {
  return (
    <div>
      This is Footer
    </div>
  )
}

export default Footer
