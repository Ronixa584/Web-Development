// import { useEffect, useState } from "react";
// import { Link } from "react-router-dom";

// export const Header = () => {
//   const [isOpen, setIsOpen] = useState(false);
//   const [isOpenNested, setIsOpenNested] = useState(false);

//   const toggle = () => {
//     setIsOpen(!isOpen);
//   };

//   const toggleNested = () => {
//     setIsOpenNested(!isOpenNested);
//   };

//   const closeDropdown = () => {
//     setIsOpen(false);
//   };

//   const closeDropdownNested = () => {
//     setIsOpenNested(false);
//   };

//   useEffect(() => {
//     const handleOutsideClick = (e) => {
//       if ((isOpen || isOpenNested) && !e.target.closest(".dropdown")) {
//         closeDropdown();
//         closeDropdownNested();
//       }
//     };

//     document.body.addEventListener("click", handleOutsideClick);

//     return () => {
//       document.body.removeEventListener("click", handleOutsideClick);
//     };
//   }, [isOpen, isOpenNested]);

//   return (
//     <header className="border border-black flex flex-col smCustom:flex-row items-center justify-center z-10 bg-transparent bg-gradient-to-br from-blue-700 via-blue-300 to-blue-700">
//       <div className=" smCustom:w-1/4">
//         <img
//           src="./ISL.png"
//           alt="ISL Logo"
//           className="h-44 smCustom:h-40 smCustom:max-smCustom:w-52 lg:ml-8"
//         />
//       </div>
//       <div className=" p-4 m-3 smCustom:w-3/4 flex items-center justify-center smCustom:justify-end">
//         <ul className="px-4 flex flex-wrap flex-col smCustom:flex-row gap-2 font-mono text-lg text-center ">
//           <div className="dropdown ">
//             <button
//               className=" px-4 main border-b-2 border-black smCustom:border-collapse"
//               onClick={toggle}
//             >
//               Teams<i className="fa fa-caret-down ml-2"></i>
//             </button>
//             <div
//               className={`list ${
//                 isOpen ? "block" : "hidden"
//               } z-10 absolute bg-transparent w-20 grid justify-center py-1 ml-3 smCustom:ml-0`}
//             >
//               <li className=" p-2 border-b-2 border-black bg-gradient-to-br from-blue-700 via-blue-300 to-blue-700">
//                 South Teams
//               </li>
//               <li className=" p-2 border-b-2 border-black  bg-gradient-to-br from-blue-700 via-blue-300 to-blue-700">
//                 North Teams
//               </li>
//               <li
//                 className="p-2 border-b-2 border-black  bg-gradient-to-br from-blue-700 via-blue-300 to-blue-700"
//                 onClick={toggleNested}
//               >
//                 West Teams
//                 <i className="fa fa-caret-down ml-2 transform -rotate-90"></i>
//               </li>
//               {isOpenNested && (
//                 <div
//                   className={`list ${
//                     isOpenNested ? "block" : "hidden"
//                   } z-10 absolute bg-transparent w-20 grid justify-center py-[148px] smCustom:py-[151px] ml-20`}
//                 >
//                   <li className="ml-1 p-2 border-b-2 border-black bg-gradient-to-br from-blue-700 via-blue-300 to-blue-700">
//                     FC Goa
//                   </li>
//                   <li className="ml-1 p-2 border-b-2 border-black  bg-gradient-to-br from-blue-700 via-blue-300 to-blue-700">
//                     Mumbai City FC
//                   </li>
//                   {/* <li className="ml-1 p-2 border-b-2 border-black  bg-gradient-to-br from-blue-700 via-blue-300 to-blue-700">
//                     Mohan Bagan FC
//                   </li> */}
//                 </div>
//               )}
//               <li className="p-2 border-b-2 border-black  bg-gradient-to-br from-blue-700 via-blue-300 to-blue-700">
//                 East Teams
//               </li>
//             </div>
//           </div>
//           {/* </div> */}
//           <li className="px-4 border-b-2 border-black">News</li>
//           <li className="px-4 border-b-2 border-black">Table</li>
//           <li className="px-4 border-b-2 border-black">Stats</li>
//           <li className="px-4 border-b-2 border-black">Players</li>
//         </ul>
//       </div>
//     </header>
//   );
// };




import { Link } from "react-router-dom";

export const Header = () => {
  function handleClick() {
    if (collapseMenu.style.display === "block") {
      collapseMenu.style.display = "none";
    } else {
      collapseMenu.style.display = "block";
    }
  }

  return (
    <header className="shadow-md bg-white fixed top-0 w-full z-10 ">
      <section className="flex border border-black flex-col md:flex-row md:justify-center md:items-center md:max-lg:gap-7 lg:justify-around justify-between">
        <div className="flex justify-between ">
          <img
            src="./logo.jpg"
            alt="ISL Logo"
            className="max-w-[21vw] h-[85px]"
          />

          <div className="flex items-center px-10 md:order-1 overflow-x-auto md:hidden">
            {/* <div className=" ml-auto md:order-1 md:hidden ">/ */}
            <button
              id="toggle"
              className=" rounded p-2 bg-[#6e5e31]"
              onClick={handleClick}
            >
              <svg
                className="w-8 h-6 text-white "
                fill="#FFFFFF"
                viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fill-rule="evenodd"
                  d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                  clip-rule="evenodd"
                ></path>
              </svg>
            </button>
            {/* </div> */}
          </div>
        </div>

        <div>
          <ul
            id="collapseMenu"
            className="font-[Philosopher-Regular] md:!flex justify-center block  text-center w-full md:gap-6 "
          >
            <li className=" py-2 hover:border-black hover:border-b-2">
              <Link to="/" className="text-[16px] block">
                Overview
              </Link>
            </li>
            <li className="  py-2 hover:border-black hover:border-b-2">
              <Link to="/" className=" text-[16px] block">
                Gallery
              </Link>
            </li>
            <li className=" py-2 hover:border-black hover:border-b-2">
              <Link to="/" className=" text-[16px] block">
                Floor Plan
              </Link>
            </li>
            <li className="  py-2 hover:border-black hover:border-b-2">
              <Link to="/" className=" text-[16px] block">
                Location
              </Link>
            </li>
            <li className="  py-2 hover:border-black hover:border-b-2">
              <Link to="/" className="text-[16px] block">
                About
              </Link>
            </li>
            <li className="flex items-center justify-center gap-2  hover:border-black hover:border-b-2">
              <img src="./phone-call.png" alt="ISL Logo" className="h-[20px]" />
              <Link to="/" className=" text-[16px] block">
                +912241498607
              </Link>
            </li>
          </ul>
        </div>
      </section>
    </header>
  );
};






