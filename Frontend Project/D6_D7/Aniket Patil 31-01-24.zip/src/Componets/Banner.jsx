import React from "react";

const Banner = () => {
    const backgroundImageUrl1 = "./banner.png";
    const backgroundImageUrl2 = "./bannersm.png";
    return (
      <>
        <div
          className="object-cover relative hidden sm:block"
          style={{
            backgroundImage: `url(${backgroundImageUrl1})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            height: "634px",
            marginTop: "85px",
            zIndex: 0,
          }}
        ></div>
        <div
          className=" relative sm:hidden"
          style={{
            backgroundImage: `url(${backgroundImageUrl2})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            height: "634px",
            marginTop: "85px", // Adjust this value based on your header height
            zIndex: 0, // Set a lower z-index for the banner
          }}
        >
          {/* <div className="w-[150px] top-1/2 h-[30px] text-white -rotate-90 bg-[#6e5e31]">
            Download Brochure
          </div> */}
        </div>
      </>
    );
};

export default Banner;
